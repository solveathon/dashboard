from redis import Redis

redisDB = Redis(host='localhost', port=6379)

# Set key with a TTL of 15 minutes (900 seconds)
# redisDB.setex('key', 900, 'value')

# Get the value of the key
# value = redisDB.get('key')
# print(value)

# Delete the key
# redisDB.delete('key')

# Python
# Check if the key exists
# if redisDB.exists('key'):
#     print("Key exists.")
# else:
#     print("Key does not exist.")

# Python
# keys = redisDB.keys('*')
# for key in keys:
#     value = redisDB.get(key)
#     print(f"Key: {key}, Value: {value}")

# Python
# redisDB.flushdb()
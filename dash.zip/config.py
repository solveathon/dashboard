firebaseConfig = {
  'apiKey': "AIzaSyAhN-pd2O_FHUWM5LuTWr3F4kzZSmuK-f0",
  'authDomain': "solveathon.firebaseapp.com",
  'projectId': "solveathon",
  'storageBucket': "solveathon.appspot.com",
  'messagingSenderId': "338107484418",
  'appId': "1:338107484418:web:1db0835f33fc3204f2da1b",
  'measurementId': "G-23H9143496",
  'databaseURL': "https://solveathon-default-rtdb.asia-southeast1.firebasedatabase.app",
}